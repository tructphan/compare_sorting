package application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

public class HomeScreenController {

    final ObservableList<String> mealList =
            FXCollections.observableArrayList("breakfast", "lunch", "dinner", "snack");

    @FXML
    private ComboBox<String> meal;
    @FXML
    private Label mealResponse;
    @FXML
    private void initialize() {
        meal.setItems(mealList);
    }
    @FXML
    void updateMeal(ActionEvent event) {

    }
}
